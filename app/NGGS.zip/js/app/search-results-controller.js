(function() {
    'use strict';
    
    angular.module('emiApp')
        .controller('searchResultsController', searchResultsController)
        .factory('searchResultsService', searchResultsService);

    searchResultsController.$inject = ['searchResultsService'];
    function searchResultsController(searchResultsService) {
        var srvm = this;

        srvm.context = searchResultsService;
        srvm.context.loadData();
    }

    searchResultsService.$inject = ['$location', '$http']
    function searchResultsService($location, $http) {
        var views = {
            list: {name: "List", url: "templates/search-results-list.html", icon: "list"},
            card: {name: "Cards", url: "templates/search-results-card.html", icon: "call_to_action"}
        };
        
        var api = {
            views: views,
            showBackButton: false,
            searchResultsText: "",
            searchResults: {
                view: null,
                data: []
            },
            loadData: loadData,
            showSearchResultsView: showSearchResultsView,
            setSearchResultsView: setSearchResultsView,
            setView: setView,
            itemDetails: itemDetails
        }

        var baseSearchResult = [];

        return api;

        function showSearchResultsView($mdOpenMenu, event) {
            $mdOpenMenu(event);
        }

        function setSearchResultsView(view) {
            api.searchResults.view = view;
        }

        function itemDetails(item) {
            if(item.assortment) {
                $location.path('search/item/assortment')
            }
            else if (item.shipper) {
                $location.path('search/item/shipper')
            }
            else {
                $location.path('/item/'+item.gtin);
            }
        }

        function setView(view) {
            api.view = view;
        }

        function loadData() {
            $http({
                method: 'GET',
                url: 'data/search-results.json'
            }).then(
                function(response) {
                    baseSearchResult = response.data;
                    api.searchResults.data = baseSearchResult;

                    api.setSearchResultsView(views.list)
                }
            )
        }
    }
})();