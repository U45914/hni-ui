(function() {
    'use strict';
    
    angular.module('item-details')
        .directive('attributeContainer', attributeContainer);
    
    function attributeContainer() {
        
    }
})();