(function() {
    'use strict';
    
    angular.module('item-details')
        .filter('attributeFilter', attributeFilter);
    
    function attributeFilter() {
        
    }
})();